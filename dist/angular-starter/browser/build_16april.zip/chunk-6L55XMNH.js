import"./chunk-35PI25VP.js";var t=[{path:"",loadComponent:()=>import("./chunk-BEMNRPM6.js").then(o=>o.StudentProfileComponent)}];export{t as PROFILE_ROUTES};
