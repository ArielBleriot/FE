import"./chunk-35PI25VP.js";var o=[{path:"",loadComponent:()=>import("./chunk-54V6G3NT.js").then(t=>t.ActivitiesComponent)}];export{o as ACTIVITIES_ROUTES};
