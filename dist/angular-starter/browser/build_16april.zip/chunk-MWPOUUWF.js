import"./chunk-35PI25VP.js";var t=[{path:"",loadComponent:()=>import("./chunk-S2R33MDO.js").then(o=>o.FaqComponent)}];export{t as FAQ_ROUTES};
