import"./chunk-35PI25VP.js";var t=[{path:"",loadComponent:()=>import("./chunk-DDFWQTRZ.js").then(o=>o.DashboardComponent)}];export{t as DASHBOARD_ROUTES};
