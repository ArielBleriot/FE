import"./chunk-35PI25VP.js";var o=[{path:"",loadComponent:()=>import("./chunk-CVVRVLDP.js").then(t=>t.StudentProjectsComponent)}];export{o as STUDENT_PROJECTS_ROUTES};
